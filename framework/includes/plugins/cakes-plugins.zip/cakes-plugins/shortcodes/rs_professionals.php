<?php
/**
 *
 * Professionals section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function professionals_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit'       => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'post',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

    <section class="meet-our-team scale-text">
      <div class="container container1200">
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <?php
              global $post;
              $loop = new WP_Query($args);
              while ( $loop->have_posts() ) : $loop->the_post();
              $specialty = get_post_meta($post->ID, "specialty", true);
              $do_not_duplicate = $post->ID;
            ?>
              <div class="swiper-slide">
                <?php if ( has_post_thumbnail() ) : ?>
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                  <?php the_post_thumbnail('carousel-thumb'); ?>
                  </a>
                <?php endif; ?>
                <h4 class="name">
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_title(); ?>
                  </a>
                </h4>
                <strong class="post"><?php echo $specialty ?></strong>
                <div class="description"><?php the_excerpt(); ?></div>
              </div>

            <?php endwhile; ?>
            <?php wp_reset_query(); ?>

          </div>
          <ul class="flex-direction-nav">
            <li>
              <a class="flex-prev" href="#">Previous</a>
            </li>
            <li>
              <a class="flex-next" href="#">Next</a>
            </li>
          </ul>
        </div><!-- .swiper-container -->
      </div><!-- .container container1200 -->

  </section><!-- .meet-our-team scale-text -->

  <?php return ob_get_clean();
}

add_shortcode( 'professionals', 'professionals_init' );
