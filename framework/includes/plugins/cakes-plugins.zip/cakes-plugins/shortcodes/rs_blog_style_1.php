<?php
/**
 *
 * Blog style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function blog_style_1_init( $atts, $content = '', $id = '' ) {
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit' 		  => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'post',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
    'posts_per_page'   => $limit,
  	'paged'	           =>	$paged,

  );

  ob_start();


  $loop = new WP_Query($args); ?>

  <section class="blog-list-content container">
    <div class="wrap">
      <div class="inner">

        <div class="drop">
          <label for="text-label">Filter by:</label>
          <input type="text" value="All" id="text-label"/>
          <a href="#" class="drop-list"></a>
          <span>
            <a href="#" class="filter" data-filter="all">All</a>
            <a href="#" class="filter" data-filter=".date">Date</a>
            <a href="#" class="filter" data-filter=".name">Name</a>
            <a href="#" class="filter" data-filter=".category">Category</a>
          </span>
        </div>
        <div class="posts container-mix">

          <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

          <article class="mix date">
            <figure class="circle-thumb time-500">
            <?php if ( has_post_thumbnail() ) : ?>
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
              <?php the_post_thumbnail('blog_style_1'); ?>
              <span class="blog-img-mask"></span>
              </a>
            <?php endif; ?>
            </figure>
            <div class="meta">
              <time datetime="<?php the_date('Y-m-d'); ?>"><?php the_time('M j, Y'); ?></time>
              <a href="<?php the_permalink(); ?>#comments-blog" class="comments"><?php get_comments_number(); ?></a>
              <?php the_tags(''); ?>
            </div>
            <h2 class="title post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <div class="description">
              <p><?php the_excerpt(); ?></p>
            </div>
          </article>

          <?php endwhile; ?>

          <nav class="page-navigation" role="navigation">
          <?php if($loop->max_num_pages>1) : ?>
            <?php if ($paged > 1) : ?>
              <a href="<?php echo '?paged=' . ($paged -1); ?>" class="previous-page">previous page</a>
            <?php else: ?>
              <a href="#" class="previous-page not-visible">previous page</a>
            <?php endif; ?>

              <ul class="pages">
              <?php for($i=1;$i<=$loop->max_num_pages;$i++) : ?>
                <li <?php echo ($paged==$i)? 'class="active"':'';?>>
                  <a href="<?php echo '?paged=' . $i; ?>"><?php echo $i;?></a>
                </li>
              <?php endfor; ?>
              </ul>

            <?php if($paged < $loop->max_num_pages) : ?>
              <a href="<?php echo '?paged=' . ($paged + 1); ?>" class="next-page">next page</a>
            <?php else: ?>
              <a href="#" class="next-page not-visible">next page</a>
            <?php endif; ?>

          <?php endif; ?>
          </nav>



          <?php wp_reset_query(); ?>

        </div><!-- .posts container-mix -->

      </div><!-- .inner -->
    </div><!-- .wrap -->
  </section>

  <?php return ob_get_clean();

}

add_shortcode( 'blog_style_1', 'blog_style_1_init' );
