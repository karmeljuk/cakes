<?php
/**
 *
 * Blog style 1
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function blog_init( $atts, $content = '', $id = '' ) {
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

  extract( shortcode_atts( array(
    'id'            => '',
    'class'         => '',
    'cats'          => '',
    'limit'         => '',
    'blog_template' => '',
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'post',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
    'posts_per_page'   => $limit,
  	'paged'	           =>	$paged,
  );

  ob_start();

  global $post;
  $loop = new WP_Query($args); ?>
  <?php if ($blog_template == "blog_style_1") : ?>
    <section class="blog-list-content container">
      <div class="wrap">
        <div class="inner">
          <div class="posts container-mix">

            <?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

            <article class="mix date">
              <figure class="circle-thumb time-500">
              <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                <?php the_post_thumbnail('blog_style_1'); ?>
                <span class="blog-img-mask"></span>
                </a>
              <?php endif; ?>
              </figure>
              <div class="meta">
                <time datetime="<?php the_date('Y-m-d'); ?>"><?php the_time('M j, Y'); ?></time>
                <a href="<?php the_permalink(); ?>#comments-blog" class="comments"><?php echo $post->comment_count ?></a>
                <?php the_tags(''); ?>
              </div>
              <h2 class="title post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
              <div class="description">
                <p><?php the_excerpt(); ?></p>
              </div>
            </article>

            <?php endwhile; ?>

            <nav class="page-navigation" role="navigation">
            <?php if($loop->max_num_pages>1) : ?>
              <?php if ($paged > 1) : ?>
                <a href="<?php echo '?paged=' . ($paged -1); ?>" class="previous-page">previous page</a>
              <?php else: ?>
                <a href="#" class="previous-page not-visible">previous page</a>
              <?php endif; ?>

                <ul class="pages">
                <?php for($i=1;$i<=$loop->max_num_pages;$i++) : ?>
                  <li <?php echo ($paged==$i)? 'class="active"':'';?>>
                    <a href="<?php echo '?paged=' . $i; ?>"><?php echo $i;?></a>
                  </li>
                <?php endfor; ?>
                </ul>

              <?php if($paged < $loop->max_num_pages) : ?>
                <a href="<?php echo '?paged=' . ($paged + 1); ?>" class="next-page">next page</a>
              <?php else: ?>
                <a href="#" class="next-page not-visible">next page</a>
              <?php endif; ?>

            <?php endif; ?>
            </nav>

            <?php //wp_reset_query(); ?>

          </div><!-- .posts container-mix -->

        </div><!-- .inner -->
      </div><!-- .wrap -->
    </section>
  <?php else: ?>
    <section class="blog-archive-content container">
      <div class="wrap">
        <div class="inner">
          <div class="events loaded-content" id="content">

            <?php
              $year_check = '';
              pbd_alp_init($loop);
              $y = 1;
              while ( $loop->have_posts() ) : $loop->the_post();
              $year = get_the_date('Y');
            ?>

            <div class="ajax-post">
              <?php if ($year !== $year_check): ?>
                <div class="ico_year_shape"><span><?php echo $year; ?></span></div>
              <?php endif; ?>
              <?php $year_check = $year; ?>

              <article class="<?php if ($y++ % 2 == 0) {echo 'fl';} else {echo 'fr';}; ?> scale-text">
                <div class="ico_date_shape">
                  <span><?php the_time('d'); ?><br><?php the_time('M'); ?></span>
                </div>
                <div class="blog-item-wrap">
                  <div class="img-block">
                    <figure>
                      <?php if ( has_post_thumbnail() ) : ?>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                        <?php the_post_thumbnail('history', array( 'class' => 'imgBorder' )); ?>
                        </a>
                      <?php endif; ?>
                    </figure>
                  </div>
                  <div class="text-block">
                    <h2 class="title post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="description"><?php the_excerpt(); ?></div>
                  </div>
                </div>
              </article>
            </div><!-- .post -->

            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
            <div class="clr"></div>

          </div><!-- .events loaded-content -->

          <p id="articleLoad">
            <a href="#" class="show-more-items ico arrow-down large"><span class="rounded-ico large red"></span></a>
          </p>

        </div><!-- .inner -->
      </div><!-- .wrap -->
    </section>
  <?php endif; ?>

  <?php return ob_get_clean();

}

add_shortcode( 'blog', 'blog_init' );
