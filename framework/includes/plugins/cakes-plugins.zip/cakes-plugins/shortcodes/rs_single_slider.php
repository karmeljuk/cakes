<?php
/**
 *
 * Single slider for blog posts
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function single_slider_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit' 		  => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'single_slider',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'single-slider-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <div class="gallery">
    <div class="swiper-container">
      <div class="swiper-wrapper">

      <?php
        $loop = new WP_Query($args);
        while ( $loop->have_posts() ) : $loop->the_post();
      ?>

      <div class="swiper-slide">
        <?php if ( has_post_thumbnail() ) : ?>
          <?php the_post_thumbnail('single_slider'); ?>
        <?php endif; ?>
      </div>

      <?php endwhile; ?>
      <?php wp_reset_postdata(); ?>

    </div><!-- .swiper-wrapper -->
    <ul class="flex-direction-nav">
      <li>
        <a class="flex-prev" href="#"></a>
      </li>
      <li>
        <a class="flex-next" href="#"></a>
      </li>
    </ul>
  </div><!-- .swiper-container -->
  <div class="pagination"></div>
</div><!-- .gallery -->

  <?php return ob_get_clean();
}

add_shortcode( 'single_slider', 'single_slider_init' );
