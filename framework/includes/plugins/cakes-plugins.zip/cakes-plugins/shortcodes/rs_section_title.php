<?php
/**
 *
 * Section Title
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function section_title_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'white'           => '',
    'title'           => '',
    'size'            => '',
    'description'     => '',
  ), $atts ) );

  $title = ( !empty($title)) ? '<'.$size.'>'.$title.'</'.$size.'>':'';
  $description = ( !empty($description)) ? '<div class="description">'.$description.'</div>':'';

  $output  = '<div class="container">';
  $output .= '<div class="wrap">';
  $output .= '<div class="inner">';
	$output .= '<div class="section-title '.$white.'">';
  $output .= $title;
	$output .= $description;
	$output .= '</div></div></div></div>';

  return $output;

}
add_shortcode( 'section_title', 'section_title_init' );
