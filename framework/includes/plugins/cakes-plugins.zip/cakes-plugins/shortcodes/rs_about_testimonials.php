<?php
/**
 *
 * About Page Testimonials section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function about_testimonials_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'cats'            => '',
    'limit'           => '',
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'content',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'content-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <section class="testimonials scale-text">

    <div class="container">
      <div class="swiper-container">
        <div class="swiper-wrapper">

          <?php
            $loop = new WP_Query($args);
            while ( $loop->have_posts() ) : $loop->the_post();
          ?>

          <div class="swiper-slide">
            <div class="container">
              <div class="content">
                <div class="inner">
                  <blockquote><?php the_content(); ?></blockquote>
                  <h4 class="author"><?php the_title(); ?></h4>
                </div>
              </div>
            </div>
          </div>

        <?php endwhile; ?>
        <?php wp_reset_query(); ?>

        </div><!-- .swiper-wrapper -->
        <ul class="flex-direction-nav">
          <li>
            <a class="flex-prev" href="#"></a>
          </li>
          <li>
            <a class="flex-next" href="#"></a>
          </li>
        </ul>
      </div><!-- .swiper-container -->
    </div><!-- .container -->

  </section>

  <?php return ob_get_clean();
}

add_shortcode( 'about_testimonials', 'about_testimonials_init' );
