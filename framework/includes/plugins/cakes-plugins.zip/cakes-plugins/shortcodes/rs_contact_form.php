<?php
/**
 *
 * C ontact Form
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_form_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
  ), $atts ) );

  $output  =  '<section class="contact-content">';
  $output .=  '<div class="container">';
  $output .=  '<div class="wrap">';
  $output .=  '<div class="inner">';
  $output .=  '<div class="contact-form scale-text">';
  $output .=  do_shortcode('[contact-form-7 id="'.$id.'"]');
  $output .=  '</div></div></div></div>';
  $output .=  '</section>';

  return $output;

}
add_shortcode( 'contact_form', 'contact_form_init' );
