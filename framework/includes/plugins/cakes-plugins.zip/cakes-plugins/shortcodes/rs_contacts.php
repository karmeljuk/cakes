<?php
/**
 *
 * Contact Holder
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_holder_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
  ), $atts ) );

  $output  =  '<section class="contact-content">';
  $output .=  '<div class="container">';
  $output .=  '<div class="wrap">';
  $output .=  '<div class="inner">';
  $output .=  '<div class="contact-info">';
  $output .=  do_shortcode($content);
  $output .=  '</div></div></div></div>';
  $output .=  '</section>';


  return $output;

}
add_shortcode( 'contact_holder', 'contact_holder_init' );



/**
 *
 * Contact Items
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_items_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'             => '',
    'content_type'   => '',
    'address'        => '',
    'address_icon'   => '',
    'phone_1'        => '',
    'phone_2'        => '',
    'phone_icon'     => '',
    'email_1'        => '',
    'email_2'        => '',
    'email_icon'     => '',
  ), $atts ) );

  if ($content_type == 'address_item'){
    $address = (!empty($address) ) ? '<div class="information">'.$address.'</div>':'';

    if (is_numeric($address_icon) && !empty( $address_icon ) ) {
      $url = wp_get_attachment_url($address_icon);
      $address_icon = '<div class="rounded-ico larger ico-contact"><img src="'.$url.'" alt=""></div>';
    }

      $output  =  '<div class="item contact-address">';
      $output .=  $address_icon;
      $output .=  '<div class="information">';
      $output .=  $address;
      $output .=  '</div>';
      $output .=  '</div>';
  }

  if ($content_type == 'phone_item'){
    $phone_1 = (!empty($phone_1) ) ? '<p><a href="tel:'.$phone_1.'">'.$phone_1.'</a><p>':'';
    $phone_2 = (!empty($phone_2) ) ? '<p><a href="tel:'.$phone_2.'">'.$phone_2.'</a><p>':'';

    if (is_numeric($phone_icon) && !empty( $phone_icon ) ) {
      $url = wp_get_attachment_url($phone_icon);
      $phone_icon = '<div class="rounded-ico larger ico-contact"><img src="'.$url.'" alt=""></div>';
    }

      $output  =  '<div class="item contact-phone">';
      $output .=  $phone_icon;
      $output .=  '<div class="information">';
      $output .=  $phone_1;
      $output .=  $phone_2;
      $output .=  '</div>';
      $output .=  '</div>';
  }

  if ($content_type == 'email_item'){
    $email_1 = (!empty($email_1) ) ? '<p><a href="mailto:'.$email_1.'">'.$email_1.'</a></p>':'';
    $email_2 = (!empty($email_2) ) ? '<p><a href="mailto:'.$email_2.'">'.$email_2.'</a></p>':'';

    if (is_numeric($email_icon) && !empty( $email_icon ) ) {
      $url = wp_get_attachment_url($email_icon);
      $email_icon = '<div class="rounded-ico larger ico-contact"><img src="'.$url.'" alt=""></div>';
    }

      $output  =  '<div class="item contact-email">';
      $output .=  $email_icon;
      $output .=  '<div class="information">';
      $output .=  $email_1;
      $output .=  $email_2;
      $output .=  '</div>';
      $output .=  '</div>';
  }
  return $output;

}
add_shortcode( 'contact_items', 'contact_items_init' );
