<?php
/**
 *
 * Services Best Offers Section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function best_offers_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit'       => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'product',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'product-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <section class="services-content">
    <div class="best-offers">
      <div class="container container1200">
        <div class="slider">
          <div class="swiper-container">
            <div class="swiper-wrapper animation-service">

              <?php
                $time = 2;
                $time = ($time > 5) ? 2 : $time;
                $loop = new WP_Query($args);
                while ( $loop->have_posts() ) : $loop->the_post();
              ?>

              <div class="swiper-slide scale-text">
                <div class="item translate time-<?php echo $time++ * 100; ?>">
                  <?php if ( has_post_thumbnail() ) : ?>
                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_post_thumbnail('best_offers-thumb'); ?>
                    </a>
                  <?php endif; ?>
                  <div class="infoDashed">
                    <div class="information">
                      <strong class="price">
                        <span class="through"><?php echo rwmb_meta('old_product_price'); ?></span>
                        <?php echo ' ' . rwmb_meta('product_price'); ?>
                      </strong>
                      <h4 class="name">
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                          <?php the_title(); ?>
                        </a>
                      </h4>
                      <div class="intro"><?php echo rwmb_meta('product_intro'); ?></div>
                      <div class="description"><?php echo rwmb_meta('product_description'); ?></div>
                    </div>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>
            </div>
            <ul class="flex-direction-nav">
              <li>
                <a class="flex-prev" href="#"></a>
              </li>
              <li>
                <a class="flex-next" href="#"></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div><!-- .best-offers -->
  </section><!-- .services-content -->

  <?php return ob_get_clean();
}

add_shortcode( 'best_offers', 'best_offers_init' );
