<?php
/**
 *
 * Blog style 2 section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function blog_style_2_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'             => '',
    'class'          => '',
    'cats'           => '',
    'limit' 		     => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'post',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <section class="blog-archive-content container">
    <div class="wrap">
      <div class="inner">
        <div class="events loaded-content">

          <?php
            $year_check = '';
            $loop = new WP_Query($args);
            $y = 1;
            while ( $loop->have_posts() ) : $loop->the_post();
            $year = get_the_date('Y');
          ?>

          <?php if ($year !== $year_check): ?>
            <div class="ico_year_shape"><span><?php echo $year; ?></span></div>
          <?php endif; ?>
          <?php $year_check = $year; ?>

            <article class="<?php if ($y++ % 2 == 0) {echo 'fl';} else {echo 'fr';}; ?> scale-text">
              <div class="ico_date_shape">
                <span><?php the_time('d'); ?><br><?php the_time('M'); ?></span>
              </div>
              <div class="blog-item-wrap">
                <div class="img-block">
                  <figure>
                    <?php if ( has_post_thumbnail() ) : ?>
                      <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                      <?php the_post_thumbnail('history', array( 'class' => 'imgBorder' )); ?>
                      </a>
                    <?php endif; ?>
                  </figure>
                </div>
                <div class="text-block">
                  <h2 class="title post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                  <div class="description"><?php the_excerpt(); ?></div>
                </div>
              </div>
            </article>

            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
            <div class="clr"></div>
        </div>

        <p id="articleLoad">
          <a href="#" class="show-more-items ico arrow-down large"><span class="rounded-ico large red"></span></a>
        </p>

      </div><!-- .inner -->
    </div><!-- .wrap -->
  </section>

  <?php return ob_get_clean();

}

add_shortcode( 'blog_style_2', 'blog_style_2_init' );
