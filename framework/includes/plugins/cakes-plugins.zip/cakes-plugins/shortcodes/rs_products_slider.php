<?php
/**
 *
 * Products Slider Section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function products_slider_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'             => '',
    'class'          => '',
    'cats'           => '',
    'limit'          => '',
  ), $atts ) );

  $args = array(
    'post_type'      => 'product',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'product-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
    'posts_per_page' => $limit,
  );

  ob_start(); ?>

  <section class="home-products scale-text">
    <div class="swiper-container">
      <div class="swiper-wrapper">
      <?php
        $loop = new WP_Query($args);
        while ( $loop->have_posts() ) : $loop->the_post();
        global $post;
        $product_price = get_post_meta($post->ID, "product_price", true);
        $product_price_old = get_post_meta($post->ID, "product_price_old", true);
      ?>

      <div class="swiper-slide">
        <div class="container">
          <div class="wrap">
            <div class="inner">
              <div class="content">
                <?php if ( has_post_thumbnail() ) : ?>
                  <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="image hidden-xs-757">
                  <?php the_post_thumbnail('products_slider'); ?>
                  </a>
                <?php endif; ?>
                <div class="information">
                  <div class="wrap">
                    <h4 class="name">
                      <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                        <?php the_title(); ?>
                      </a>
                    </h4>
                    <div class="description"><?php the_excerpt(); ?></div>
                    <strong class="price">
                      <?php if ( !empty(rwmb_meta('old_product_price'))): ?>
                      <span class="through"><?php echo rwmb_meta('old_product_price'); ?></span>
                      <?php endif; ?>
                      <?php echo ' ' . rwmb_meta('product_price'); ?>
                    </strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div><!-- .swiper-slide -->

      <?php endwhile; ?>
      <?php wp_reset_query(); ?>
      </div><!-- .swiper-wrapper -->
      <ul class="flex-direction-nav">
        <li>
          <a class="flex-prev" href="#"></a>
        </li>
        <li>
          <a class="flex-next" href="#"></a>
        </li>
      </ul>
    </div><!-- .swiper-container -->
  </section><!-- .home-products -->

  <?php return ob_get_clean();
}

add_shortcode( 'products_slider', 'products_slider_init' );
