<?php
/**
 *
 * Products section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function products_init( $atts, $content = '', $id = '' ) {
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit'       => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'product',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'product-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
    'paged'          => $paged,
  );

  ob_start(); ?>

  <section class="products-content container">
    <div class="drop">
     <label for="text-label">Filter by:</label>
      <input type="text" value="All" id="text-label"/>
      <a href="#" class="drop-list"></a>
        <span>
          <a href="#" class="filter" data-filter="all">All</a>
          <?php
            $categories = get_categories(array('taxonomy' => 'product-category','child_of' => $cats));
            foreach ($categories as $category) :
          ?>
            <a href="#" class="filter" data-filter=".<?php echo $category->slug; ?>"><?php echo $category->name; ?></a>
          <?php endforeach; ?>
        </span>
    </div>
    <div class="content product-animation">

      <div class="items" id="content">
        <div class="loaded-content container-mix">
          <?php
            global $post;
            $loop = new WP_Query($args);
            pbd_alp_init($loop);
            while ( $loop->have_posts() ) : $loop->the_post();
            $terms = get_the_terms($post->ID, "product-category");
            $term = array_shift( $terms );
            $cat_name = $term->slug;
          ?>
          <div class="<?php echo $cat_name; ?> product mix scale-text ajax-post">
            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
              <?php if ( has_post_thumbnail() ) : ?>
                <?php the_post_thumbnail('products'); ?>
              <?php endif; ?>
              <h4 class="name">
                <?php the_title(); ?>
              </h4>
            </a>
            <div class="intro"><?php echo rwmb_meta('product_intro'); ?></div>
            <div class="description"><?php the_excerpt(); ?></div>
            <strong class="price">
              <span class="through"><?php echo rwmb_meta('old_product_price'); ?></span>
              <?php echo ' ' . rwmb_meta('product_price'); ?>
            </strong>
          </div>

          <?php endwhile; ?>
          <?php wp_reset_postdata(); ?>
        </div>
      </div>

      <p id="articleLoad">
        <a href="#" class="show-more-items ico arrow-down large"><span class="rounded-ico large red"></span></a>
      </p>

    </div>
  </section><!-- .meet-our-team scale-text -->

  <?php return ob_get_clean();
}

add_shortcode( 'products', 'products_init' );
