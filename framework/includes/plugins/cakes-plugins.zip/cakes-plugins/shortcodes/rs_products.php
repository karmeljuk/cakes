<?php
/**
 *
 * Products section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function products_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'          => '',
    'class'       => '',
    'cats'        => '',
    'limit'       => ''
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'product',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'product-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <section class="products-content container">
    <div class="drop">
     <label for="text-label">Filter by:</label>
      <input type="text" value="All" id="text-label"/>
      <a href="#" class="drop-list"></a>
        <span>
          <a href="#" class="filter" data-filter="all">All</a>
          <?php
            $categories = get_categories(array('taxonomy' => 'product-category','child_of' => $cats));
            foreach ($categories as $category) :
          ?>
            <a href="#" class="filter" data-filter=".<?php echo $category->slug; ?>"><?php echo $category->name; ?></a>
          <?php endforeach; ?>
        </span>
    </div>
    <div class="content product-animation">
      <ul class="items loaded-content container-mix">
        <?php
          global $post;
          $loop = new WP_Query($args);
          while ( $loop->have_posts() ) : $loop->the_post();
          $terms = get_the_terms($post->ID, "product-category");
          $term = array_shift( $terms );
          $cat_name = $term->slug;
        ?>
        <li class="<?php echo $cat_name; ?> product mix scale-text">
          <div class="">
            <?php if ( has_post_thumbnail() ) : ?>
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
              <?php the_post_thumbnail('products'); ?>
              </a>
            <?php endif; ?>
            <h4 class="name">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                <?php the_title(); ?>
              </a>
            </h4>
            <?php if ( !empty(rwmb_meta('product_intro'))): ?>
            <div class="intro"><?php echo rwmb_meta('product_intro'); ?></div>
            <?php endif; ?>
            <div class="description"><?php the_excerpt(); ?></div>
            <strong class="price">
              <?php if ( !empty(rwmb_meta('old_product_price'))): ?>
              <span class="through"><?php echo rwmb_meta('old_product_price'); ?></span>
              <?php endif; ?>
              <?php echo ' ' . rwmb_meta('product_price'); ?>
            </strong>
          </div>
        </li>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
      </ul>
      <div class="clr"></div>
      <a href="#" id="itemLoad" class="show-more-items ico arrow-down large">
      <span class="rounded-ico large"></span></a>
    </div>
  </section><!-- .meet-our-team scale-text -->

  <?php return ob_get_clean();
}

add_shortcode( 'products', 'products_init' );
