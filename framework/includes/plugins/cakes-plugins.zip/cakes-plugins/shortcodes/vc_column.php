<?php
/**
 *
 * VC COLUMN and VC COLUMN INNER
 * @since 1.0.0
 * @version 1.0.0
 *
 */

function cakes_column( $atts, $content = '', $id = '' ) {
	extract( shortcode_atts( array(
		'id'        => '',
		'class'     => '',
		'css'			  => '',
    'fixed_bg'  => ''
	), $atts ) );

  $first  = strpos($css, "{");
  $second = substr($css, $first+1);
  $styles = explode("}", $second);
  $styles = $styles[0];

  if( !empty($fixed_bg)) {
    $fixed_bg = 'fixed_bg';
  }

  $output  = '<div class="vc_row wpb_row vc_row-fluid '.$fixed_bg.'" style="'.$styles.'">';
  $output .= do_shortcode($content);
  $output .= '</div>';
  return $output;

}
add_shortcode('vc_row', 'cakes_column');
add_shortcode('vc_row', 'cakes_column');
