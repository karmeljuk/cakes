<?php
/**
 *
 * Features Slider Section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function feature_slider_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'cats'            => '',
    'limit'           => '',
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'feature',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'feature-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

    <div class="home-slider full-height full-min-height">
      <div class="fixed-baner">
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <?php
              $loop = new WP_Query($args);
              while ( $loop->have_posts() ) : $loop->the_post();
            ?>
            <div class="swiper-slide">
              <div class="bg bg-bg"  style="background-image: url('<?php $dom = simplexml_load_string(get_the_post_thumbnail()); $src = $dom->attributes()->src; echo $src; ?>');"></div>
              <div class="container">
                <div class="top_bottom">
                  <div class="table">
                    <div class="t_td">
                      <div class="description animation-rotate hidden-320"><?php echo rwmb_meta('f_top_text'); ?></div>
                      <h2 class="animation-scale"><?php echo rwmb_meta('f_bottom_text'); ?></h2>
                      <a href="<?php echo rwmb_meta('f_link_url'); ?>" class="btn red animation-btn"><?php echo rwmb_meta('f_link_text'); ?></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endwhile; ?>
            <?php wp_reset_query(); ?>
          </div>
          <div class="pagination" data-0="margin-bottom:0px;" data-400="margin-bottom:100px;"></div>
        </div>
      </div>
    </div>

  <?php return ob_get_clean();
}

add_shortcode( 'feature_slider', 'feature_slider_init' );
