<?php
/**
 *
 * Services section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function services_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'            => '',
    'class'         => '',
    'cats'          => '',
    'limit'         => '',
    'page_id'       => '',
    'button_text'   => '',
  ), $atts ) );

  $args = array(
  	'post_type'	     => 'post',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
  	'posts_per_page' =>	$limit,
  );

  ob_start(); ?>

  <section class="services-content">
    <div class="container">
      <div class="services">
        <ul class="items <?php if ( !is_front_page() ) { echo 'animation-service'; } ?>">
        <?php
          $page = get_post($page_id);
          $page_slug = $page->post_name;
          $item = 1;
          $times = array(300, 400, 500);
          $startCount = 3;
          $startTime = 0;
          $count = 0;
          $loop = new WP_Query($args);
          while ( $loop->have_posts() ) : $loop->the_post();
            if( $count < $startCount ) {
              $time = $startTime;
            }
            else {
              $time = $times[ $count % count( $times ) ];
            }
        ?>

          <li class="item-<?php echo $item++;  ?> scale-text">
            <div class="translate time-<?php echo $time++; ?>">
              <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="image">
                <?php the_post_thumbnail('services-thumb'); ?>
                </a>
              <?php endif; ?>
              <h3>
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                  <?php the_title(); ?>
                </a>
              </h3>
              <div class="description"><?php the_excerpt(); ?></div>
            </div>
          </li>
          <?php ++$count; ?>
          <?php endwhile; ?>
          <?php wp_reset_postdata(); ?>

        </ul>
      </div><!-- .services -->
      <?php if ( !empty($page_id)) : ?>
      <a href="<?php echo $page_slug; ?>" class="btn brown"><?php echo $button_text; ?></a>
      <?php endif; ?>
    </div><!-- .container -->
  </section><!-- .services-content -->

  <?php return ob_get_clean();
}

add_shortcode( 'services', 'services_init' );
