<?php
/**
 *
 * RS Contact Items
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_items_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'address'    => '',
    'phone_number_1'      => '',
    'phone_number_2'      => '',
    'mail_1'       => '',
    'mail_2'       => '',
  ), $atts ) );

    $output  =  '<section class="contact-content">';
    $output .=  '<div class="container">';
    $output .=  '<div class="wrap">';
    $output .=  '<div class="inner">';
    $output .=  '<div class="contact-info">';

    if(!empty($address)) {
      $output .=  '<div class="item contact-address">';
      $output .=  '<div class="rounded-ico larger ico-contact"></div>';
      $output .=  '<div class="information">'.$address.'</div>';
      $output .=  '</div>';
    }

    if(!empty($phone_number_1) || !empty($phone_number_2))  {
      $output .=  '<div class="item contact-phone">';
      $output .=  '<div class="rounded-ico larger ico-contact"></div>';
      $output .=  '<div class="information">';
      $output .=  '<p><a href="tel:'.$phone_number_1.'">'.$phone_number_1.'</a></p>';
      $output .=  '<p><a href="tel:'.$phone_number_2.'">'.$phone_number_2.'</a></p>';
      $output .=  '</div>';//.information
      $output .=  '</div>';//.item contact-phone
    }

    if(!empty($mail_1) || !empty($mail_2)) {
      $output .=  '<div class="item contact-email">';
      $output .=  '<div class="rounded-ico larger ico-contact"></div>';
      $output .=  '<div class="information">';
      $output .=  '<p><a href="mailto:'.$mail_1.'">'.$mail_1.'</a></p>';
      $output .=  '<p><a href="mailto:'.$mail_2.'">'.$mail_2.'</a></p>';
      $output .=  '</div>';//.information
      $output .=  '</div>';//.item contact-address
    }

    $output .=  '</div></div></div></div>';
    $output .=  '</section>';


  return $output;

}
add_shortcode( 'contact_items', 'contact_items_init' );
