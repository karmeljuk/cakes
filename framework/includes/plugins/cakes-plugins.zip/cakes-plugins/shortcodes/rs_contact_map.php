<?php
/**
 *
 * Contact Map section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_map_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'         => '',
    'lat'        => '',
    'lng'        => '',
    'zoom'       => ''
  ), $atts ) );


if ($lat != '' && $lng != '') {
	$output = '<div id="contact-map" data-lat="'. $lat .'" data-lng="'. $lng .'" data-zoom="'. $zoom .'" data-string=""></div>';
}

  return $output;

}
add_shortcode( 'contact_map', 'contact_map_init' );
