<?php
/**
 *
 * Contact Map section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function contact_map_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'         => '',
    'lat'        => '',
    'lng'        => '',
    'zoom'       => '',
    'map_icon'   => ''
  ), $atts ) );

if (is_numeric($map_icon) && !empty( $map_icon ) ) {
  $map_icon = wp_get_attachment_url($map_icon);
  // $map_icon = '<img src="'.$url.'" alt="">';
}

if ($lat != '' && $lng != '') {
	$output = '<div id="contact-map" data-lat="'. $lat .'" data-lng="'. $lng .'" data-zoom="'. $zoom .'" data-string="" data-image="'. $map_icon .'"></div>';
}

  return $output;

}
add_shortcode( 'contact_map', 'contact_map_init' );
