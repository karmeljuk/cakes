<?php
/**
 *
 * Our History section
 * @since 1.0.0
 * @version 1.1.0
 *
 */


function history_init( $atts, $content = '', $id = '' ) {
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'cats'            => '',
    'limit' 		      => ''
  ), $atts ) );

  $args = array(
    'post_type'      => 'content',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'content-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
    'posts_per_page' => $limit,
    'paged'          => $paged,

  );

  ob_start(); ?>

  <section class="our-history">
    <div class="wrap container">
      <div class="inner">
        <div class="events loaded-content" id="content">

        <?php
          $year_check = '';
          $loop = new WP_Query($args);
          pbd_alp_init($loop);
          $i = 1;
          while ( $loop->have_posts() ) : $loop->the_post();
          $year = get_the_date('Y');
        ?>

          <div class="ajax-post">
            <?php if ($year !== $year_check): ?>
              <div class="ico_year_shape_history"><span><?php echo $year; ?></span></div>
            <?php endif; ?>
            <?php $year_check = $year; ?>

              <article class="<?php if ($i++ % 2 == 0) {echo 'right';} else {echo 'left';}; ?>-item scale-text">
                <div class="ico_date_shape_history">
                  <span><?php the_time('d'); ?><br><?php the_time('M'); ?></span>
                </div>
                <div class="img-block">
                  <figure>
                    <?php if ( has_post_thumbnail() ) : ?>
                      <?php the_post_thumbnail('history', array( 'class' => 'imgBorder' )); ?>
                    <?php endif; ?>
                  </figure>
                </div>
                <div class="text-block">
                  <h2 class="title post-title"><?php the_title(); ?></h2>
                  <div class="description"><?php the_excerpt(); ?></div>
                </div>
              </article>
          </div>

          <?php endwhile; ?>
          <?php wp_reset_query(); ?>
        </div>

        <p id="articleLoad">
          <a href="#" class="show-more-items ico arrow-down large"><span class="rounded-ico large red"></span></a>
        </p>

      </div>
    </div>
  </section>

  <?php return ob_get_clean();
}

add_shortcode( 'history', 'history_init' );
