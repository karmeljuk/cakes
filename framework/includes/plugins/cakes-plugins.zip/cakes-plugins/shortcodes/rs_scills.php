<?php
/**
 *
 * Scills Holder
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function scills_holder_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
  ), $atts ) );

  $output  = '<section class="services-content">';
  $output .= '<div class="our-skills container">';
  $output .= '<div class="skills">';
  $output .= do_shortcode($content);
  $output .= '</div>';
  $output .= '</div>';
  $output .= '</section>';

  return $output;

}
add_shortcode( 'scills_holder', 'scills_holder_init' );


/**
 *
 * Scills items
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function scills_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'white'           => '',
    'title'           => '',
    'size'            => '',
    'description'     => '',
    'percent'         => '',
    'icon'            => '',
  ), $atts ) );

  $title = ( !empty($title)) ? '<'.$size.'>'.$title.'</'.$size.'>':'';
  $description = ( !empty($description)) ? '<div class="description2">'.$description.'</div>':'';

  if (is_numeric($icon) && !empty( $icon ) ) {
    $url = wp_get_attachment_url($icon);
    $icon = '<div class="spinner skill-icon" style="background-image: url('.$url.');"></div>';
  }

  $data_percent = 100 - $percent;

  $output  = '<div class="item">';
  $output .= '<div class="statistic" data-percent="'.$percent.'%">';
  $output .= $icon;
  $output .= '<div class="spinner fill"></div>';
  $output .= '<div class="pr">';
  $output .= '<div data-dimension="250" data-text="'.$percent.'%" data-info="" data-width="18" data-fontsize="22" data-percent="'.$data_percent.'" data-fgcolor="#f5f4f4" data-bgcolor="transparent" data-fill="transparent" class="circliful" style="" data-animationstep="1"></div>';
  $output .= '</div>';//.pr
  $output .= '</div>';//.statistic
  $output .= $title;
	$output .= $description;
  $output .= '</div>';//.item

  return $output;

}
add_shortcode( 'scills', 'scills_init' );
