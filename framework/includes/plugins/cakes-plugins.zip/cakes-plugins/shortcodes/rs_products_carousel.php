<?php
/**
 *
 * Products Carousel Section
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function products_carousel_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'             => '',
    'class'          => '',
    'cats'           => '',
    'limit'          => '',
    'page_id'        => '',
    'button_text'    => '',
  ), $atts ) );

  $args = array(
    'post_type'      => 'product',
    'tax_query'      => array(
      array(
        'taxonomy'   => 'product-category',
        'field'      => 'ids',
        'terms'      => explode(',', $cats),
      ),
    ),
    'posts_per_page' => $limit,
  );

  ob_start(); ?>

  <section class="home-services scale-text">
    <div class="container container1200">
      <div class="swiper-container">
        <div class="swiper-wrapper">
        <?php
          $page = get_post($page_id);
          $page_slug = $page->post_name;
          $loop = new WP_Query($args);
          while ( $loop->have_posts() ) : $loop->the_post();
        ?>

          <div class="swiper-slide">
            <?php if ( has_post_thumbnail() ) : ?>
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
              <?php the_post_thumbnail('products-carousel-thumb'); ?>
              </a>
            <?php endif; ?>
            <h4 class="name">
              <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                <?php the_title(); ?>
              </a>
            </h4>
            <div class="description"><?php the_excerpt(); ?></div>
          </div><!-- .swiper-slide -->

        <?php endwhile; ?>
        <?php wp_reset_query(); ?>
        </div><!-- .swiper-wrapper -->
        <ul class="flex-direction-nav">
          <li>
            <a class="flex-prev" href="#"></a>
          </li>
          <li>
            <a class="flex-next" href="#"></a>
          </li>
        </ul>
      </div><!-- .swiper-container -->
      <?php if ( !empty($page_id)) : ?>
      <a href="<?php echo $page_slug; ?>" class="btn brown"><?php echo $button_text; ?></a>
      <?php endif; ?>
    </div><!-- .container -->
  </section><!-- .home-services -->

  <?php return ob_get_clean();
}

add_shortcode( 'products_carousel', 'products_carousel_init' );
