<?php
/**
 *
 * Page Title
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function page_title_init( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'              => '',
    'white'           => '',
    'title'           => '',
    'description'     => '',
  ), $atts ) );


  $title = ( !empty($title)) ? '<h1>'.$title.'</h1>':'';
  $description = ( !empty($description)) ? '<div class="description">'.$description.'</div>':'';

  $output  = '<div class="container">';
  $output .= '<div class="wrap">';
  $output .= '<div class="inner">';
  $output .= '<div class="page-title '.$white.'">';
  $output .= $title;
  $output .= $description;
  $output .= '</div></div></div></div>';

  return $output;

}
add_shortcode( 'page_title', 'page_title_init' );
