<?php
/*
Plugin Name: Cakes Plugins
Plugin URI: http://graphicriver.net/user/InvisioThemes
Author: InvisioThemes
Author URI: http://graphicriver.net/user/InvisioThemes
Version: 1.0
Description: Includes Custom Post Types and Visual Composer Shortcodes
Text Domain: cakes
*/

// Define Constants
defined('EF_ROOT')		or define('EF_ROOT', dirname(__FILE__));
defined('EF_VERSION')	or define('EF_VERSION', '1.0');


//echo EF_ROOT;

if(!class_exists('Cakes_Plugins')) {

	class Cakes_Plugins {

		private $assets_js;

		public function __construct() {
			$this->assets_js	= plugins_url('/composer/js', __FILE__);
      add_action('init', array($this, 'feature_post_type'), 0);
      add_action('init', array($this, 'product_post_type'), 0);
      add_action('init', array($this, 'content_post_type'), 0);
      add_action('init', array($this, 'single_slider_post_type'), 0);
			add_action('admin_init', array($this, 'cakes_load_map'));
			add_action('admin_print_scripts-post.php', array($this, 'vc_enqueue_scripts'), 99);
			add_action('admin_print_scripts-post-new.php', array($this, 'vc_enqueue_scripts'), 99);
			$this->cakes_load_shortcodes();
		}

    /**
     * Feature Custom Post Type
     */
    public function feature_post_type() {

      $labels = array(
        'name'                => _x( 'Features', 'Post Type General Name', 'cakes' ),
        'singular_name'       => _x( 'Feature', 'Post Type Singular Name', 'cakes' ),
        'menu_name'           => __( 'Feature', 'cakes' ),
        'parent_item_colon'   => __( 'Parent Feature:', 'cakes' ),
        'all_items'           => __( 'All Features', 'cakes' ),
        'view_item'           => __( 'View Feature', 'cakes' ),
        'add_new_item'        => __( 'Add New Feature', 'cakes' ),
        'add_new'             => __( 'Add New', 'cakes' ),
        'edit_item'           => __( 'Edit Feature', 'cakes' ),
        'update_item'         => __( 'Update Feature', 'cakes' ),
        'search_items'        => __( 'Search Feature', 'cakes' ),
        'not_found'           => __( 'Not found', 'cakes' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'cakes' ),
      );
      $args = array(
        'label'               => __( 'feature', 'cakes' ),
        'description'         => __( 'Feature Post Type', 'cakes' ),
        'labels'              => $labels,
        'supports'            => array( 'title','thumbnail' ),
        'taxonomies'          => array( 'feature-category' ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'menu_icon'           => 'dashicons-images-alt',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
      );
      register_post_type( 'feature', $args );

    }

    /**
     * Product Custom Post Type
     */
    public function product_post_type() {

      $labels = array(
        'name'                => _x( 'Products', 'Post Type General Name', 'cakes' ),
        'singular_name'       => _x( 'Product', 'Post Type Singular Name', 'cakes' ),
        'menu_name'           => __( 'Product', 'cakes' ),
        'parent_item_colon'   => __( 'Parent Product:', 'cakes' ),
        'all_items'           => __( 'All Products', 'cakes' ),
        'view_item'           => __( 'View Product', 'cakes' ),
        'add_new_item'        => __( 'Add New Product', 'cakes' ),
        'add_new'             => __( 'Add New', 'cakes' ),
        'edit_item'           => __( 'Edit Product', 'cakes' ),
        'update_item'         => __( 'Update Product', 'cakes' ),
        'search_items'        => __( 'Search Product', 'cakes' ),
        'not_found'           => __( 'Not found', 'cakes' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'cakes' ),
      );
      $args = array(
        'label'               => __( 'product', 'cakes' ),
        'description'         => __( 'Product Post Type', 'cakes' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
        'taxonomies'          => array( 'product-category' ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 6,
        'menu_icon'           => 'dashicons-cart',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
      );
      register_post_type( 'product', $args );

      $taxonomy_labels                = array(
        'name'                        => 'Category',
        'singular_name'               => 'Category',
        'menu_name'                   => 'Categories',
        'all_items'                   => 'All Categories',
        'parent_item'                 => 'Parent Category',
        'parent_item_colon'           => 'Parent Category:',
        'new_item_name'               => 'New Category Name',
        'add_new_item'                => 'Add New Category',
        'edit_item'                   => 'Edit Category',
        'update_item'                 => 'Update Category',
        'separate_items_with_commas'  => 'Separate categories with commas',
        'search_items'                => 'Search categories',
        'add_or_remove_items'         => 'Add or remove categories',
        'choose_from_most_used'       => 'Choose from the most used categories',
      );

      $taxonomy_rewrite         = array(
        'slug'                  => 'product-category',
        'with_front'            => true,
        'hierarchical'          => true,
      );

      $taxonomy_args          = array(
        'labels'              => $taxonomy_labels,
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_admin_column'   => true,
        'show_in_nav_menus'   => true,
        'show_tagcloud'       => true,
        'rewrite'             => $taxonomy_rewrite,
      );
      register_taxonomy( 'product-category', 'product', $taxonomy_args );

    }

    /**
     * Content Custom Post Type
     */
    public function content_post_type() {

      $labels = array(
        'name'                => _x( 'Contents', 'Post Type General Name', 'cakes' ),
        'singular_name'       => _x( 'Content', 'Post Type Singular Name', 'cakes' ),
        'menu_name'           => __( 'Content', 'cakes' ),
        'parent_item_colon'   => __( 'Parent Content:', 'cakes' ),
        'all_items'           => __( 'All Contents', 'cakes' ),
        'view_item'           => __( 'View Content', 'cakes' ),
        'add_new_item'        => __( 'Add New Content', 'cakes' ),
        'add_new'             => __( 'Add New', 'cakes' ),
        'edit_item'           => __( 'Edit Content', 'cakes' ),
        'update_item'         => __( 'Update Content', 'cakes' ),
        'search_items'        => __( 'Search Content', 'cakes' ),
        'not_found'           => __( 'Not found', 'cakes' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'cakes' ),
      );
      $args = array(
        'label'               => __( 'content', 'cakes' ),
        'description'         => __( 'Content Post Type', 'cakes' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', ),
        'taxonomies'          => array( 'content-category' ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 7,
        'menu_icon'           => 'dashicons-media-document',
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
      );
      register_post_type( 'content', $args );

      $taxonomy_labels                = array(
        'name'                        => 'Category',
        'singular_name'               => 'Category',
        'menu_name'                   => 'Categories',
        'all_items'                   => 'All Categories',
        'parent_item'                 => 'Parent Category',
        'parent_item_colon'           => 'Parent Category:',
        'new_item_name'               => 'New Category Name',
        'add_new_item'                => 'Add New Category',
        'edit_item'                   => 'Edit Category',
        'update_item'                 => 'Update Category',
        'separate_items_with_commas'  => 'Separate categories with commas',
        'search_items'                => 'Search categories',
        'add_or_remove_items'         => 'Add or remove categories',
        'choose_from_most_used'       => 'Choose from the most used categories',
      );

      $taxonomy_rewrite         = array(
        'slug'                  => 'content-category',
        'with_front'            => true,
        'hierarchical'          => true,
      );

      $taxonomy_args          = array(
        'labels'              => $taxonomy_labels,
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_admin_column'   => true,
        'show_in_nav_menus'   => true,
        'show_tagcloud'       => true,
        'rewrite'             => $taxonomy_rewrite,
      );
      register_taxonomy( 'content-category', 'content', $taxonomy_args );

    }

    /**
     * Single Slider
     */
    public function single_slider_post_type() {

      $labels = array(
        'name'                => _x( 'Single Sliders', 'Post Type General Name', 'cakes' ),
        'singular_name'       => _x( 'Single Slider', 'Post Type Singular Name', 'cakes' ),
        'menu_name'           => __( 'Single Slider', 'cakes' ),
        'parent_item_colon'   => __( 'Parent Item:', 'cakes' ),
        'all_items'           => __( 'All Items', 'cakes' ),
        'view_item'           => __( 'View Item', 'cakes' ),
        'add_new_item'        => __( 'Add New Item', 'cakes' ),
        'add_new'             => __( 'Add New', 'cakes' ),
        'edit_item'           => __( 'Edit Item', 'cakes' ),
        'update_item'         => __( 'Update Item', 'cakes' ),
        'search_items'        => __( 'Search Item', 'cakes' ),
        'not_found'           => __( 'Not found', 'cakes' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'cakes' ),
      );
      $args = array(
        'label'               => __( 'single_slider', 'cakes' ),
        'description'         => __( 'Single Slider for Single Posts', 'cakes' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'thumbnail', ),
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 8,
        'menu_icon'           => 'dashicons-images-alt2',
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => true,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
      );
      register_post_type( 'single_slider', $args );

      $taxonomy_labels                = array(
        'name'                        => 'Category',
        'singular_name'               => 'Category',
        'menu_name'                   => 'Categories',
        'all_items'                   => 'All Categories',
        'parent_item'                 => 'Parent Category',
        'parent_item_colon'           => 'Parent Category:',
        'new_item_name'               => 'New Category Name',
        'add_new_item'                => 'Add New Category',
        'edit_item'                   => 'Edit Category',
        'update_item'                 => 'Update Category',
        'separate_items_with_commas'  => 'Separate categories with commas',
        'search_items'                => 'Search categories',
        'add_or_remove_items'         => 'Add or remove categories',
        'choose_from_most_used'       => 'Choose from the most used categories',
      );

      $taxonomy_rewrite         = array(
        'slug'                  => 'single-slider-category',
        'with_front'            => true,
        'hierarchical'          => true,
      );

      $taxonomy_args          = array(
        'labels'              => $taxonomy_labels,
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_admin_column'   => true,
        'show_in_nav_menus'   => true,
        'show_tagcloud'       => true,
        'rewrite'             => $taxonomy_rewrite,
      );
      register_taxonomy( 'single-slider-category', 'single_slider', $taxonomy_args );

    }




		public function cakes_load_map() {
			if(class_exists('Vc_Manager')) {
				require_once( EF_ROOT .'/'. 'composer/map.php');
				require_once( EF_ROOT .'/'. 'composer/init.php');
			}
		}

		public function cakes_load_shortcodes() {

			foreach( glob( EF_ROOT . '/'. 'shortcodes/rs_*.php' ) as $shortcode ) {
				require_once(EF_ROOT .'/'. 'shortcodes/'. basename( $shortcode ) );
			}

			foreach( glob( EF_ROOT . '/'. 'shortcodes/vc_*.php' ) as $shortcode ) {
				require_once(EF_ROOT .'/' .'shortcodes/'. basename( $shortcode ) );
			}

		}

		public function vc_enqueue_scripts() {
			wp_enqueue_script( 'vc-script', $this->assets_js .'/vc-script.js' ,  array('jquery'), '1.0.0', true );
		}

	} // end of class

	new Cakes_Plugins;
} // end of class_exists
