<?php
/**
  * WPBakery Visual Composer Shortcodes settings
  *
  * @package VPBakeryVisualComposer
  *
 */

// Include Helpers
//include_once( T_PATH . '/' . F_DIR . '/composer/helpers.php' );
include_once( EF_ROOT . '/composer/params.php' );

if ( ! function_exists( 'is_plugin_active' ) ) {
  include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
}

// ==========================================================================================
// Visual Compose Row
// ==========================================================================================
vc_map( array(
  'name' => __( 'Row', 'js_composer' ),
  'base' => 'vc_row',
  'is_container' => true,
  'icon' => 'icon-wpb-row',
  'show_settings_on_create' => false,
  'category' => __( 'Content', 'js_composer' ),
  'description' => __( 'Place content elements inside the row', 'js_composer' ),
  'params' => array(
    array(
      'type' => 'colorpicker',
      'heading' => __( 'Font Color', 'js_composer' ),
      'param_name' => 'font_color',
      'description' => __( 'Select font color', 'js_composer' ),
      'edit_field_class' => 'vc_col-md-6 vc_column'
    ),
    array(
      'type' => 'textfield',
      'heading' => __( 'Extra class name', 'js_composer' ),
      'param_name' => 'el_class',
      'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
    ),
    array(
      'type' => 'css_editor',
      'heading' => __( 'Css', 'js_composer' ),
      'param_name' => 'css',
      'group' => __( 'Design options', 'js_composer' )
    ),
    array(
      'type' => 'checkbox',
      'param_name' => 'fixed_bg',
      'description' => __( 'Enables Section Fixed Background.', 'js_composer' ),
      'value' => array( __( 'Fixed Background', 'js_composer' ) => 'fixed_bg' ),
      'group' => __( 'Design options', 'js_composer' )
    ),
  ),
  'js_view' => 'VcRowView'
) );

// CONTACT FORM 7
// ==========================================================================================
if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {

  global $wpdb;

  $db_cf7froms  = $wpdb->get_results("SELECT ID, post_title FROM $wpdb->posts WHERE post_type = 'wpcf7_contact_form'");
  $cf7_forms    = array();

  if ( $db_cf7froms ) {

    foreach ( $db_cf7froms as $cform ) {
      $cf7_forms[$cform->post_title] = $cform->ID;
    }

  } else {
    $cf7_forms['No contact forms found'] = 0;
  }

  vc_map( array(
    'name'            => 'Contact Form',
    'base'            => 'contact_form',
    'icon'            => '',
    'description'     => 'Contact Form 7',
    'params'          => array(
      array(
        'type'        => 'dropdown',
        'heading'     => 'Contact Form',
        'param_name'  => 'id',
        'value'       => $cf7_forms,
        'admin_label' => true,
        'description' => 'Choose previously created contact form from the drop down list.',
      )
    )
  ) );
}

// ==========================================================================================
// Page Title
// ==========================================================================================
vc_map( array(
  'name'            => 'Page Title',
  'base'            => 'page_title',
  'icon'            => '',
  'description'     => 'Custom Title',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Page Title',
      'param_name'  => 'title',
      'value'       => 'Default title',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'White Heading?',
      'param_name'  => 'white',
      'value'       =>  array('No' => '', 'Yes' => 'white'),
      'admin_label' =>  true
    ),
    array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'description' => 'Leave blank to hide description',
      'admin_label' =>  true
    )
  )

) );

// ==========================================================================================
// Section Title
// ==========================================================================================
vc_map( array(
  'name'            => 'Section Title',
  'base'            => 'section_title',
  'icon'            => '',
  'description'     => 'Custom Title',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Section Title',
      'param_name'  => 'title',
      'value'       => 'Default title',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Heading',
      'param_name'  => 'size',
      'value'       => array(
        'H1'        =>  'h1',
        'H2'        =>  'h2',
        'H3'        =>  'h3'
      )
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'White Heading?',
      'param_name'  => 'white',
      'value'       =>  array('No' => '', 'Yes' => 'white'),
      'admin_label' =>  true
    ),
    array(
      'type'        => 'textarea',
      'heading'     => 'Description',
      'param_name'  => 'description',
      'description' => 'Leave blank to hide description',
      'admin_label' =>  true
    )
  )

) );

// ==========================================================================================
// Contact Us blocks
// ==========================================================================================
vc_map( array(
  'name'            => 'Contact Us Items',
  'base'            => 'contact_items',
  'icon'            => '',
  'description'     => 'Welcome Text',
  'params'          => array(
    array(
      'type'        => 'textarea',
      'heading'     => 'Address Text',
      'param_name'  => 'address',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'First Phone Number',
      'param_name'  => 'phone_number_1',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Second Phone Number',
      'param_name'  => 'phone_number_2',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'First Mail',
      'param_name'  => 'mail_1',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Second Mail',
      'param_name'  => 'mail_2',
    ),
  )

) );


// ==========================================================================================
// Contact Map Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Contact Map',
  'base'            => 'contact_map',
  'icon'            => '',
  'description'     => 'Custom Google Map',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Latitude',
      'param_name'  => 'lat',
      'value'       => '43.640645',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Longitude',
      'param_name'  => 'lng',
      'value'       => '-79.431200',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Map Zoom',
      'param_name'  => 'zoom',
      'value'       => '15',
    ),
  )

) );

// ==========================================================================================
// Blog style 1 Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Blog style 1',
  'base'            => 'blog_style_1',
  'icon'            => '',
  'description'     => 'Create a blog',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for blog, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Posts Per Page',
      'param_name'  => 'limit',
      'value'       => 4,
      'admin_label' => true
    )
  )

) );

// ==========================================================================================
// Blog style 2 Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Blog style 2',
  'base'            => 'blog_style_2',
  'icon'            => '',
  'description'     => 'Create a blog',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for blog, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Posts Per Page',
      'param_name'  => 'limit',
      'value'       => 6,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Image Gallery Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Image Gallery',
  'base'            => 'image_gallery',
  'icon'            => '',
  'description'     => 'Create Image Gallery Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'single-slider-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    ),
    array(
      'type'        => 'textarea_html',
      'heading'     => 'Page Article',
      'param_name'  => 'article',
      'description' => 'Leave blank to hide description',
      'admin_label' =>  true
    ),
  )

) );


// ==========================================================================================
// History Section
// ==========================================================================================
vc_map( array(
  'name'            => 'History',
  'base'            => 'history',
  'icon'            => '',
  'description'     => 'Create a History Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'history-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for blog, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Posts Per Page',
      'param_name'  => 'limit',
      'value'       => 8,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Professionals Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Professionals',
  'base'            => 'professionals',
  'icon'            => '',
  'description'     => 'Create Professionals Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 8,
      'admin_label' => true
    )
  )

) );

// ==========================================================================================
// About Page Testimonials section
// ==========================================================================================
vc_map( array(
  'name'            => 'About Page Testimonials',
  'base'            => 'about_testimonials',
  'icon'            => '',
  'description'     => 'Create a slider',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    ),
  )

) );

// ==========================================================================================
// Products Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Products',
  'base'            => 'products',
  'icon'            => '',
  'description'     => 'Create Products Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'product-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Products on page',
      'param_name'  => 'limit',
      'value'       => 12,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Services Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Services',
  'base'            => 'services',
  'icon'            => '',
  'description'     => 'Create Services Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of items',
      'param_name'  => 'limit',
      'value'       => 9,
      'admin_label' => true
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Page to link',
      'param_name'  => 'page_id',
      'placeholder' => 'Choose page for link (optional)',
      'value'       => cakes_element_values( 'page', array(
        'sort_order'  => 'ASC',
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific page to link',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button link text',
      'param_name'  => 'button_text',
      'description' => 'text for button',
      'value'       => 'view more',
    ),
  )

) );

// ==========================================================================================
// Services Best Offers Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Best Offers',
  'base'            => 'best_offers',
  'icon'            => '',
  'description'     => 'Create Best Offers Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'product-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 8,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Scills Holder
// ==========================================================================================
vc_map( array(
  'name'                    => 'Scills Holder',
  'base'                    => 'scills_holder',
  'icon'                    => '',
  'as_parent'               => array('only' => 'scills'),
  'show_settings_on_create' => true,
  'js_view'                 => 'VcColumnView',
  'content_element'         => true,
  'description'             => 'Create a pricing table',
  'params'  => array(
  )

) );


// ==========================================================================================
// Scills Items
// ==========================================================================================
vc_map( array(
  'name'            => 'Scills Item',
  'base'            => 'scills',
  'icon'            => '',
  'description'     => 'Our Scills Section',
  'as_child'        => array('only' => 'scills_holder'),
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Scill Item Title',
      'param_name'  => 'title',
      'value'       => 'Default title',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Heading',
      'param_name'  => 'size',
      'value'       => array(
        'H3'        =>  'h3',
        'H4'        =>  'h4',
        'H5'        =>  'h5'
      )
    ),
    array(
      'type'        => 'textarea',
      'heading'     => 'Scill Item Description',
      'param_name'  => 'description',
      'description' => 'Leave blank to hide description',
      'admin_label' =>  true
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Scill Percent',
      'param_name'  => 'percent',
      'value'       => '75',
      'description' => 'The number from 0 to 100',
    ),
    array(
      'type'        => 'attach_image',
      'heading'     => 'Scill Image (Optional)',
      'param_name'  => 'icon',
      'description' => 'Upload icon if you need different image for scill.'
    ),
  )

) );

// ==========================================================================================
// Features Slider Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Features Slider',
  'base'            => 'feature_slider',
  'icon'            => '',
  'description'     => 'Create a Features Slider',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'feature-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of Slides',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Products Carousel Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Products Carousel',
  'base'            => 'products_carousel',
  'icon'            => '',
  'description'     => 'Create Products Carousel Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'product-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Products on page',
      'param_name'  => 'limit',
      'value'       => 8,
      'admin_label' => true
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Page to link',
      'param_name'  => 'page_id',
      'placeholder' => 'Choose page for link (optional)',
      'value'       => cakes_element_values( 'page', array(
        'sort_order'  => 'ASC',
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific page to link',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button link text',
      'param_name'  => 'button_text',
      'description' => 'text for button',
      'value'       => 'view more',
    ),
  )

) );

// ==========================================================================================
// Products Slider Section
// ==========================================================================================
vc_map( array(
  'name'            => 'Products Slider',
  'base'            => 'products_slider',
  'icon'            => '',
  'description'     => 'Create Products Slider Section',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'product-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Products on page',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    )
  )

) );


// ==========================================================================================
// Home Page Testimonials section
// ==========================================================================================
vc_map( array(
  'name'            => 'Home Page Testimonials',
  'base'            => 'home_testimonials',
  'icon'            => '',
  'description'     => 'Create a slider',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    ),
  )

) );

// ==========================================================================================
// Single Slider
// ==========================================================================================
vc_map( array(
  'name'            => 'Single Slider',
  'base'            => 'single_slider',
  'icon'            => '',
  'description'     => 'Create a slider',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Custom Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Choose category (optional)',
      'value'       => cakes_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'single-slider-category',
        'hide_empty'  => true,
      ) ),
      'std'         => '',
      'description' => 'you can choose spesific categories for slider, default is all categories',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Number of slides',
      'param_name'  => 'limit',
      'value'       => 3,
      'admin_label' => true
    ),
  )

) );

class WPBakeryShortCode_Scills_Holder   extends WPBakeryShortCodesContainer {}

add_action( 'admin_init', 'vc_remove_elements', 10);
function vc_remove_elements( $e = array() ) {

  if ( !empty( $e ) ) {
    foreach ( $e as $key => $r_this ) {
      vc_remove_element( 'vc_'.$r_this );
    }
  }
}

$s_elemets = array( 'tabs', 'tab', 'accordion', 'accordion_tab', 'custom_heading','clients', 'widget_sidebar', 'toggle', 'images_carousel', 'carousel', 'tour', 'gallery', 'posts_slider', 'posts_grid', 'teaser_grid', 'separator', 'text_separator', 'message', 'facebook', 'tweetmeme', 'googleplus', 'pinterest', 'single_image', 'button', 'toogle', 'button2', 'cta_button', 'cta_button2', 'video', 'gmaps', 'flickr', 'progress_bar', 'raw_html', 'raw_js', 'pie', 'wp_search', 'wp_meta', 'wp_recentcomments', 'wp_calendar', 'wp_pages', 'wp_custommenu', 'wp_text', 'wp_posts', 'wp_links', 'wp_categories', 'wp_archives', 'wp_rss' );
vc_remove_element('client', 'testimonial', 'contact-form-7');
vc_remove_elements( $s_elemets );

